import React, { useState } from 'react';
import { Atmosphere } from './components/Atmosphere';
import { HomeScreen } from './components/HomeScreen';
import { ActiveWalkScreen } from './components/ActiveWalkScreen';
import { CameraScreen } from './components/CameraScreen';
import { AnalysisScreen } from './components/AnalysisScreen';
import { ObservationScreen } from './components/ObservationScreen';
import { SummaryScreen } from './components/SummaryScreen';
import { DISCOVERIES_POOL } from './data/discoveries';
import { ObservationItem, ScreenState } from './types';

export default function App() {
  const [screen, setScreen] = useState<ScreenState>('home');
  const [walkStartTime, setWalkStartTime] = useState<number | null>(null);
  const [savedObservations, setSavedObservations] = useState<ObservationItem[]>([]);
  const [currentCapturedImage, setCurrentCapturedImage] = useState<string>('');
  const [currentObservation, setCurrentObservation] = useState<ObservationItem | null>(null);
  const [discoveryIndex, setDiscoveryIndex] = useState<number>(0);

  // Helper to format current time like "09:42"
  const getCurrentFormattedTime = (): string => {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    return `${hours}:${minutes}`;
  };

  // Start a new walk
  const handleStartWalk = () => {
    setWalkStartTime(Date.now());
    setSavedObservations([]);
    setDiscoveryIndex(0);
    setScreen('active_walk');
  };

  // Open camera viewfinder from active walk
  const handleOpenCapture = () => {
    setScreen('camera');
  };

  // User clicked shutter in camera screen
  const handleCapture = (imageDataUrl: string) => {
    setCurrentCapturedImage(imageDataUrl);

    // Pick discovery metadata template in sequence
    const template = DISCOVERIES_POOL[discoveryIndex % DISCOVERIES_POOL.length];
    setDiscoveryIndex((prev) => prev + 1);

    const newObservation: ObservationItem = {
      id: `obs-${Date.now()}`,
      title: template.title,
      type: template.type,
      description: template.description,
      closerDetail: template.closerDetail,
      confidence: template.confidence,
      imageUrl: imageDataUrl || template.fallbackImage,
      timestamp: getCurrentFormattedTime(),
      capturedAt: Date.now(),
    };

    setCurrentObservation(newObservation);
    setScreen('analyzing');
  };

  // Analysis scan finishes (auto 2.6s)
  const handleAnalysisComplete = () => {
    setScreen('observation');
  };

  // Save observation to field journal and return to active walk
  const handleSaveObservation = () => {
    if (currentObservation) {
      setSavedObservations((prev) => [...prev, currentObservation]);
    }
    setCurrentObservation(null);
    setCurrentCapturedImage('');
    setScreen('active_walk');
  };

  // Discard and return to camera viewfinder
  const handleTryAgain = () => {
    setCurrentObservation(null);
    setCurrentCapturedImage('');
    setScreen('camera');
  };

  // End walk and display field journal summary
  const handleEndWalk = () => {
    // If the walk had no observations yet, seed an evocative sample so summary is never empty
    if (savedObservations.length === 0) {
      const sampleTime = getCurrentFormattedTime();
      const defaultSamples: ObservationItem[] = [
        {
          id: 'sample-1',
          title: DISCOVERIES_POOL[0].title,
          type: DISCOVERIES_POOL[0].type,
          description: DISCOVERIES_POOL[0].description,
          closerDetail: DISCOVERIES_POOL[0].closerDetail,
          confidence: DISCOVERIES_POOL[0].confidence,
          imageUrl: DISCOVERIES_POOL[0].fallbackImage,
          timestamp: sampleTime,
          capturedAt: Date.now() - 25 * 60 * 1000,
        },
        {
          id: 'sample-2',
          title: DISCOVERIES_POOL[1].title,
          type: DISCOVERIES_POOL[1].type,
          description: DISCOVERIES_POOL[1].description,
          closerDetail: DISCOVERIES_POOL[1].closerDetail,
          confidence: DISCOVERIES_POOL[1].confidence,
          imageUrl: DISCOVERIES_POOL[1].fallbackImage,
          timestamp: sampleTime,
          capturedAt: Date.now() - 12 * 60 * 1000,
        },
      ];
      setSavedObservations(defaultSamples);
    }
    setScreen('summary');
  };

  // Finish summary and return to home
  const handleDone = () => {
    setWalkStartTime(null);
    setSavedObservations([]);
    setCurrentObservation(null);
    setDiscoveryIndex(0);
    setScreen('home');
  };

  // Calculate elapsed minutes (or default to 37 min when freshly demoed)
  const getWalkDuration = (): number => {
    if (!walkStartTime) return 37;
    const elapsedMinutes = Math.round((Date.now() - walkStartTime) / 60000);
    return Math.max(elapsedMinutes, 1);
  };

  return (
    <div className="relative min-h-screen bg-[#8AC7EA] text-[#2E1B10] overflow-x-hidden">
      {/* Living Animated Whimsical Block Nature Atmosphere */}
      <Atmosphere showCelestial={screen !== 'camera'} />

      {/* Screen Router */}
      {screen === 'home' && <HomeScreen onStartWalk={handleStartWalk} />}

      {screen === 'active_walk' && (
        <ActiveWalkScreen
          noticedCount={savedObservations.length}
          onOpenCapture={handleOpenCapture}
          onEndWalk={handleEndWalk}
        />
      )}

      {screen === 'camera' && (
        <CameraScreen
          onCapture={handleCapture}
          onClose={() => setScreen('active_walk')}
        />
      )}

      {screen === 'analyzing' && (
        <AnalysisScreen
          capturedImageUrl={currentCapturedImage}
          onAnalysisComplete={handleAnalysisComplete}
        />
      )}

      {screen === 'observation' && currentObservation && (
        <ObservationScreen
          observation={currentObservation}
          onSave={handleSaveObservation}
          onTryAgain={handleTryAgain}
        />
      )}

      {screen === 'summary' && (
        <SummaryScreen
          observations={savedObservations}
          durationMinutes={getWalkDuration()}
          onDone={handleDone}
        />
      )}
    </div>
  );
}
