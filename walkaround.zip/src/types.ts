export interface ObservationItem {
  id: string;
  title: string;
  type: string;
  description: string;
  closerDetail: string;
  confidence: string;
  imageUrl: string;
  timestamp: string; // e.g. "09:42"
  capturedAt: number;
}

export type ScreenState =
  | 'home'
  | 'active_walk'
  | 'camera'
  | 'analyzing'
  | 'observation'
  | 'summary';
